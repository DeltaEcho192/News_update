with open("final_output.txt", "r") as ins:
    array = []
    for line in ins:
        array.append(line)
        
output0 = open("file0.txt","w")
output1 = open("file1.txt","w")
output2 = open("file2.txt","w")
output3 = open("file3.txt","w")
output4 = open("file4.txt","w")
output5 = open("file5.txt","w")
output6 = open("file6.txt","w")
output7 = open("file7.txt","w")
output8 = open("file8.txt","w")
output9 = open("file9.txt","w")


output0.write(array[0])
output1.write(array[1])
output2.write(array[2])
output3.write(array[3])
output4.write(array[4])
output5.write(array[5])
output6.write(array[6])
output7.write(array[7])
output8.write(array[8])
output9.write(array[9])