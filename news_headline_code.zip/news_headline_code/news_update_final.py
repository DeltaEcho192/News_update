class A(object):
    def news_update(self):
        f = open("test_output3.txt", "r")
        output = open("final_output2.txt", "w")

        output.write(f.read().replace("><h4 class=","").replace("</h4></a><time>",""))
        f.close()
        output.close()
        print("News update 1 complete")
    def news_update2(self):
        f = open("final_output2.txt", "r")
        output = open("final_output3.txt", "w")

        output.write(f.read().replace("latest-news-topic-link","").replace(">",""))
        f.close()
        output.close()
        print("News update 2 complete")
    def news_update3(self):
        f = open("final_output3.txt", "r")
        output = open("final_output.txt", "w")

        output.write(f.read().replace('"',""))
        f.close()
        output.close()
        print("News update 3 complete")
a = A()

print(a.news_update())
print(a.news_update2())
print(a.news_update3())